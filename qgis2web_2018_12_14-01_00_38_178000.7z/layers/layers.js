var wms_layers = [];
var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'OSM',
    'type': 'base',
    source: new ol.source.OSM()
})
]
});
var format__0 = new ol.format.GeoJSON();
var features__0 = format__0.readFeatures(json__0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource__0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource__0.addFeatures(features__0);var lyr__0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource__0, maxResolution:28004.4661523,

                style: style__0,
                title: '<img src="styles/legend/_0.png" /> Лінійні водні об\'єкти'
            });var format__1 = new ol.format.GeoJSON();
var features__1 = format__1.readFeatures(json__1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource__1 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource__1.addFeatures(features__1);var lyr__1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource__1, 
                style: style__1,
                title: '<img src="styles/legend/_1.png" /> Огляд водойм (осінь)'
            });var format_2018_2 = new ol.format.GeoJSON();
var features_2018_2 = format_2018_2.readFeatures(json_2018_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_2018_2 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_2018_2.addFeatures(features_2018_2);var lyr_2018_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_2018_2, 
                style: style_2018_2,
                title: '<img src="styles/legend/2018_2.png" /> Огляд водойм (літо 2018)'
            });var format__3 = new ol.format.GeoJSON();
var features__3 = format__3.readFeatures(json__3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource__3 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource__3.addFeatures(features__3);var lyr__3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource__3, 
                style: style__3,
                title: '<img src="styles/legend/_3.png" /> Огляд водойм (весна)'
            });var format__4 = new ol.format.GeoJSON();
var features__4 = format__4.readFeatures(json__4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource__4 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource__4.addFeatures(features__4);var lyr__4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource__4, 
                style: style__4,
                title: '<img src="styles/legend/_4.png" /> Точки огляду (осінь)'
            });var format__5 = new ol.format.GeoJSON();
var features__5 = format__5.readFeatures(json__5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource__5 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource__5.addFeatures(features__5);var lyr__5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource__5, 
                style: style__5,
                title: '<img src="styles/legend/_5.png" /> Точки огляду (літо)'
            });

lyr__0.setVisible(true);lyr__1.setVisible(true);lyr_2018_2.setVisible(true);lyr__3.setVisible(true);lyr__4.setVisible(true);lyr__5.setVisible(true);
var layersList = [baseLayer,lyr__0,lyr__1,lyr_2018_2,lyr__3,lyr__4,lyr__5];
lyr__0.set('fieldAliases', {'id': 'id', 'Назва': 'Назва', 'Номер': 'Номер', 'Довжи': 'Довжи', });
lyr__1.set('fieldAliases', {'id': 'id', 'Озера': 'Озера', 'Площа': 'Площа', 'Date': 'Date', 'Оцінка_еко': 'Оцінка_еко', 'Бал_берег': 'Бал_берег', 'Бал_біоцен': 'Бал_біоцен', 'Бал': 'Бал', 'Огляд': 'Огляд', 'Результат': 'Результат', 'Виконав': 'Виконав', });
lyr_2018_2.set('fieldAliases', {'id': 'id', 'Озера': 'Озера', 'Площа': 'Площа', 'Оцінка_еко': 'Оцінка_еко', 'Бал_берег': 'Бал_берег', 'Бал_біоцен': 'Бал_біоцен', 'Бал': 'Бал', 'Дата': 'Дата', 'Огляд': 'Огляд', 'Результати': 'Результати', 'Виконав': 'Виконав', });
lyr__3.set('fieldAliases', {'id': 'id', 'Озера': 'Озера', 'Площа': 'Площа', 'Бал': 'Бал', 'Оцінка_еко': 'Оцінка_еко', 'Бал_берег': 'Бал_берег', 'Бал_біоцен': 'Бал_біоцен', 'Date': 'Date', 'Огляд': 'Огляд', 'Результат': 'Результат', 'Виконав': 'Виконав', });
lyr__4.set('fieldAliases', {'id': 'id', 'Назва': 'Назва', 'Date': 'Date', 'Оцінка-еко': 'Оцінка-еко', 'Бал_берег': 'Бал_берег', 'Бал_біоцен': 'Бал_біоцен', 'Бал': 'Бал', 'Огляд': 'Огляд', 'Результати': 'Результати', 'Виконав': 'Виконав', });
lyr__5.set('fieldAliases', {'id': 'id', 'Назва': 'Назва', 'Date': 'Date', 'Оцінка_еко': 'Оцінка_еко', 'Бал_берег': 'Бал_берег', 'Бал_біоцен': 'Бал_біоцен', 'Огляд': 'Огляд', 'Результати': 'Результати', 'Виконав': 'Виконав', });
lyr__0.set('fieldImages', {'id': 'TextEdit', 'Назва': 'TextEdit', 'Номер': 'TextEdit', 'Довжи': 'TextEdit', });
lyr__1.set('fieldImages', {'id': 'TextEdit', 'Озера': 'TextEdit', 'Площа': 'TextEdit', 'Date': 'TextEdit', 'Оцінка_еко': 'TextEdit', 'Бал_берег': 'TextEdit', 'Бал_біоцен': 'TextEdit', 'Бал': 'TextEdit', 'Огляд': 'TextEdit', 'Результат': 'TextEdit', 'Виконав': 'TextEdit', });
lyr_2018_2.set('fieldImages', {'id': 'TextEdit', 'Озера': 'TextEdit', 'Площа': 'TextEdit', 'Оцінка_еко': 'TextEdit', 'Бал_берег': 'TextEdit', 'Бал_біоцен': 'TextEdit', 'Бал': 'TextEdit', 'Дата': 'TextEdit', 'Огляд': 'TextEdit', 'Результати': 'TextEdit', 'Виконав': 'TextEdit', });
lyr__3.set('fieldImages', {'id': 'TextEdit', 'Озера': 'TextEdit', 'Площа': 'TextEdit', 'Бал': 'TextEdit', 'Оцінка_еко': 'TextEdit', 'Бал_берег': 'TextEdit', 'Бал_біоцен': 'TextEdit', 'Date': 'TextEdit', 'Огляд': 'TextEdit', 'Результат': 'TextEdit', 'Виконав': 'TextEdit', });
lyr__4.set('fieldImages', {'id': 'TextEdit', 'Назва': 'TextEdit', 'Date': 'TextEdit', 'Оцінка-еко': 'TextEdit', 'Бал_берег': 'TextEdit', 'Бал_біоцен': 'TextEdit', 'Бал': 'TextEdit', 'Огляд': 'TextEdit', 'Результати': 'TextEdit', 'Виконав': 'TextEdit', });
lyr__5.set('fieldImages', {'id': 'TextEdit', 'Назва': 'TextEdit', 'Date': 'TextEdit', 'Оцінка_еко': 'TextEdit', 'Бал_берег': 'TextEdit', 'Бал_біоцен': 'TextEdit', 'Огляд': 'TextEdit', 'Результати': 'TextEdit', 'Виконав': 'TextEdit', });
lyr__0.set('fieldLabels', {'id': 'inline label', 'Назва': 'inline label', 'Номер': 'inline label', 'Довжи': 'inline label', });
lyr__1.set('fieldLabels', {'id': 'no label', 'Озера': 'inline label', 'Площа': 'inline label', 'Date': 'inline label', 'Оцінка_еко': 'inline label', 'Бал_берег': 'inline label', 'Бал_біоцен': 'inline label', 'Бал': 'inline label', 'Огляд': 'inline label', 'Результат': 'inline label', 'Виконав': 'inline label', });
lyr_2018_2.set('fieldLabels', {'id': 'inline label', 'Озера': 'inline label', 'Площа': 'inline label', 'Оцінка_еко': 'inline label', 'Бал_берег': 'inline label', 'Бал_біоцен': 'inline label', 'Бал': 'inline label', 'Дата': 'inline label', 'Огляд': 'inline label', 'Результати': 'inline label', 'Виконав': 'inline label', });
lyr__3.set('fieldLabels', {'id': 'inline label', 'Озера': 'inline label', 'Площа': 'inline label', 'Бал': 'inline label', 'Оцінка_еко': 'inline label', 'Бал_берег': 'inline label', 'Бал_біоцен': 'inline label', 'Date': 'inline label', 'Огляд': 'inline label', 'Результат': 'inline label', 'Виконав': 'inline label', });
lyr__4.set('fieldLabels', {'id': 'inline label', 'Назва': 'inline label', 'Date': 'inline label', 'Оцінка-еко': 'inline label', 'Бал_берег': 'inline label', 'Бал_біоцен': 'inline label', 'Бал': 'inline label', 'Огляд': 'inline label', 'Результати': 'inline label', 'Виконав': 'inline label', });
lyr__5.set('fieldLabels', {'id': 'no label', 'Назва': 'inline label', 'Date': 'inline label', 'Оцінка_еко': 'inline label', 'Бал_берег': 'inline label', 'Бал_біоцен': 'inline label', 'Огляд': 'inline label', 'Результати': 'inline label', 'Виконав': 'inline label', });
lyr__5.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});